import express from 'express';
import { createHash, createHmac, randomInt, randomUUID, timingSafeEqual } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { getPool } from './src/db.js';
import { runMigrations } from './src/migrations.js';
import {
  clearAppSessionCookie,
  clearOAuthStateCookie,
  createAppSession,
  getCookie,
  getPublicOriginHeader,
  isValidCsrf,
  publicOriginFromClient,
  readOAuthStateCookie,
  setAppSessionCookie,
  setOAuthStateCookie,
  verifyAppSession
} from './src/auth.js';

const app = express();
const port = Number(process.env.PORT || 3000);
const publicDir = fileURLToPath(new URL('./public/', import.meta.url));
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  if (req.path.startsWith('/api/admin/')) res.setHeader('Cache-Control', 'no-store');
  next();
});
app.use(express.json({ limit: '32kb' }));

const RATE_WINDOW_MS = 60 * 60 * 1000;
const reservationRateBuckets = new Map();
const ADMIN_LOGIN_WINDOW_MS = 15 * 60 * 1000;
const ADMIN_LOGIN_MAX_FAILURES = 5;
const adminLoginBuckets = new Map();

function consumeRateBucket(key, maxCount) {
  const now = Date.now();
  let bucket = reservationRateBuckets.get(key);
  if (!bucket || bucket.expiresAt <= now) {
    bucket = { count: 0, expiresAt: now + RATE_WINDOW_MS };
    reservationRateBuckets.set(key, bucket);
  }
  if (bucket.count >= maxCount) return Math.max(1, Math.ceil((bucket.expiresAt - now) / 1000));
  bucket.count += 1;
  if (reservationRateBuckets.size > 5000) {
    for (const [oldKey, oldBucket] of reservationRateBuckets) {
      if (oldBucket.expiresAt <= now) reservationRateBuckets.delete(oldKey);
      if (reservationRateBuckets.size <= 4000) break;
    }
  }
  return 0;
}

function reservationRateLimit(email) {
  const key = createHmac('sha256', process.env.MANUS_JWT_SECRET || 'ticket-reservation')
    .update(normalizeEmail(email)).digest('hex');
  const emailWait = consumeRateBucket(`email:${key}`, 3);
  if (emailWait) return emailWait;
  return consumeRateBucket('global', 100);
}

function releaseRateBucket(key) {
  const bucket = reservationRateBuckets.get(key);
  if (bucket && bucket.count > 0) bucket.count -= 1;
}

function releaseReservationRateLimit(email) {
  const key = createHmac('sha256', process.env.MANUS_JWT_SECRET || 'ticket-reservation')
    .update(normalizeEmail(email)).digest('hex');
  releaseRateBucket(`email:${key}`);
  releaseRateBucket('global');
}

function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase();
}

function adminLoginKey(req, email) {
  const secret = process.env.MANUS_JWT_SECRET || 'ticket-admin-login-rate-limit';
  return createHmac('sha256', secret)
    .update(`${String(req.ip || 'unknown')}:${normalizeEmail(email)}`)
    .digest('hex');
}

function adminLoginWait(req, email) {
  const bucket = adminLoginBuckets.get(adminLoginKey(req, email));
  if (!bucket || bucket.lockedUntil <= Date.now()) return 0;
  return Math.max(1, Math.ceil((bucket.lockedUntil - Date.now()) / 1000));
}

function recordAdminLoginFailure(req, email) {
  const now = Date.now();
  const key = adminLoginKey(req, email);
  let bucket = adminLoginBuckets.get(key);
  if (!bucket || bucket.lockedUntil <= now) bucket = { failures: 0, lockedUntil: 0 };
  bucket.failures += 1;
  if (bucket.failures >= ADMIN_LOGIN_MAX_FAILURES) {
    bucket.failures = 0;
    bucket.lockedUntil = now + ADMIN_LOGIN_WINDOW_MS;
  }
  adminLoginBuckets.set(key, bucket);
  if (adminLoginBuckets.size > 5000) {
    for (const [oldKey, oldBucket] of adminLoginBuckets) {
      if (oldBucket.lockedUntil <= now && oldBucket.failures === 0) adminLoginBuckets.delete(oldKey);
      if (adminLoginBuckets.size <= 4000) break;
    }
  }
  return bucket.lockedUntil > now ? Math.ceil((bucket.lockedUntil - now) / 1000) : 0;
}

function clearAdminLoginFailures(req, email) {
  adminLoginBuckets.delete(adminLoginKey(req, email));
}

function passwordsMatch(candidate, expected) {
  const candidateDigest = createHash('sha256').update(candidate).digest();
  const expectedDigest = createHash('sha256').update(expected).digest();
  return timingSafeEqual(candidateDigest, expectedDigest);
}

function validEmail(value) {
  return value.length <= 320 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function cleanText(value, maxLength) {
  return typeof value === 'string' ? value.trim().slice(0, maxLength) : '';
}

function eventFromRow(row) {
  return {
    eventTitle: row.event_title,
    eventDate: row.event_date,
    schoolName: row.school_name,
    eventLocation: row.event_location,
    visitorInstructions: row.visitor_instructions
  };
}

function parseJsonValue(value) {
  if (typeof value === 'string') {
    try { return JSON.parse(value); } catch { return {}; }
  }
  return value && typeof value === 'object' ? value : {};
}

function newTicketCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const characters = Array.from({ length: 10 }, () => alphabet[randomInt(alphabet.length)]);
  return `TKT-${characters.slice(0, 5).join('')}-${characters.slice(5).join('')}`;
}

function mapTicketRow(row) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    priceCents: Number(row.price_cents),
    isActive: Boolean(row.is_active),
    sortOrder: Number(row.sort_order)
  };
}

function noAdmin(res, status, message) {
  res.status(status).json({ error: message });
  return null;
}

async function upsertAdminUser(openId, email, name) {
  await getPool().execute(
    `INSERT INTO ticket_admin_users (open_id, email, display_name) VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE open_id = VALUES(open_id), email = VALUES(email),
       display_name = VALUES(display_name), updated_at = CURRENT_TIMESTAMP`,
    [openId, email, name]
  );
}

async function getAdminContext(req, res, { csrf = false, allowRefresh = false } = {}) {
  res.setHeader('Cache-Control', 'no-store');
  const claims = verifyAppSession(req);
  if (!claims) return noAdmin(res, 401, 'Bitte melde dich mit deinem Manus-Konto an.');

  const allowedEmail = normalizeEmail(process.env.TICKET_ADMIN_EMAIL);
  if (!allowedEmail || !validEmail(allowedEmail)) {
    return noAdmin(res, 503, 'Der Administratorzugriff ist noch nicht eingerichtet.');
  }

  let email = normalizeEmail(claims.email);
  let displayName = cleanText(claims.name, 255);
  if (!email) {
    const [rows] = await getPool().execute(
      'SELECT email, display_name FROM ticket_admin_users WHERE open_id = ? LIMIT 1',
      [claims.openId]
    );
    if (rows.length) {
      email = normalizeEmail(rows[0].email);
      displayName = cleanText(rows[0].display_name, 255);
    }
  }
  if (email !== allowedEmail) {
    return noAdmin(res, 403, 'Dieses Manus-Konto ist nicht als Administrator freigeschaltet.');
  }

  if (!claims.csrf) {
    if (!allowRefresh || csrf) {
      return noAdmin(res, 401, 'Bitte lade deine Admin-Sitzung neu und melde dich erneut an.');
    }
    const origin = getPublicOriginHeader(req);
    if (!origin) return noAdmin(res, 401, 'Die sichere Browser-Sitzung konnte nicht erneuert werden.');
    await upsertAdminUser(claims.openId, email, displayName);
    const session = createAppSession({ openId: claims.openId, email, name: displayName });
    setAppSessionCookie(res, session.token, origin);
    return { openId: claims.openId, email, name: displayName, csrfToken: session.csrfToken };
  }

  if (csrf && !isValidCsrf(claims, req.get('x-csrf-token'))) {
    return noAdmin(res, 403, 'Die Sicherheitsprüfung ist abgelaufen. Bitte lade die Seite neu.');
  }
  if (claims.email && email === allowedEmail) await upsertAdminUser(claims.openId, email, displayName);
  return { openId: claims.openId, email, name: displayName, csrfToken: claims.csrf };
}

async function getEventAndTicketRows({ activeOnly = false } = {}) {
  const pool = getPool();
  const [eventRows] = await pool.execute(
    'SELECT event_title, event_date, school_name, event_location, visitor_instructions FROM ticket_event_settings WHERE id = 1'
  );
  if (!eventRows.length) throw new Error('Die Veranstaltungsangaben sind nicht initialisiert.');
  const query = activeOnly
    ? 'SELECT id, name, description, price_cents, is_active, sort_order FROM ticket_types WHERE is_active = 1 ORDER BY sort_order, id'
    : 'SELECT id, name, description, price_cents, is_active, sort_order FROM ticket_types ORDER BY sort_order, id';
  const [ticketRows] = await pool.execute(query);
  return { event: eventFromRow(eventRows[0]), tickets: ticketRows.map(mapTicketRow) };
}

async function findExistingReservation(pool, reservationId, email) {
  const [rows] = await pool.execute(
    `SELECT id, email, total_cents, event_snapshot, email_status
     FROM ticket_reservations WHERE id = ? LIMIT 1`,
    [reservationId]
  );
  if (!rows.length) return null;
  const reservation = rows[0];
  if (normalizeEmail(reservation.email) !== email) {
    return { status: 409, body: { error: 'Dieser Reservierungsschlüssel wurde bereits verwendet.' } };
  }
  const [ticketRows] = await pool.execute(
    `SELECT ticket_code, ticket_type_id, ticket_name, ticket_description, price_cents
     FROM ticket_instances WHERE reservation_id = ? ORDER BY created_at, ticket_code`,
    [reservation.id]
  );
  return {
    status: 200,
    body: {
      reservationId: reservation.id,
      emailStatus: reservation.email_status,
      tickets: ticketRows.map((row) => ({
        ticketCode: row.ticket_code,
        ticketTypeId: row.ticket_type_id,
        ticketName: row.ticket_name,
        ticketDescription: row.ticket_description,
        priceCents: Number(row.price_cents)
      })),
      event: parseJsonValue(reservation.event_snapshot),
      totalCents: Number(reservation.total_cents)
    }
  };
}

function parseReservationCursor(rawValue) {
  const raw = String(rawValue || '');
  if (!raw) return null;
  if (raw.length > 768) return false;
  try {
    const parts = raw.split('.');
    if (parts.length !== 2 || !/^[A-Za-z0-9_-]+$/.test(parts[0]) || !/^[A-Za-z0-9_-]+$/.test(parts[1])) return false;
    const secret = process.env.MANUS_JWT_SECRET;
    if (!secret) return false;
    const expectedSignature = createHmac('sha256', secret).update(parts[0]).digest();
    const actualSignature = Buffer.from(parts[1], 'base64url');
    if (actualSignature.length !== expectedSignature.length || !timingSafeEqual(actualSignature, expectedSignature)) return false;
    const cursor = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8'));
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(cursor?.id || '')) return false;
    if (typeof cursor.createdAt !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(cursor.createdAt)) return false;
    const createdAt = new Date(cursor.createdAt);
    if (Number.isNaN(createdAt.getTime()) || createdAt.toISOString() !== cursor.createdAt) return false;
    return { id: cursor.id, createdAt };
  } catch {
    return false;
  }
}

function createReservationCursor(row) {
  const secret = process.env.MANUS_JWT_SECRET;
  if (!secret) throw new Error('Der Sitzungsschlüssel ist nicht verfügbar.');
  const payload = Buffer.from(JSON.stringify({
    id: row.id,
    createdAt: new Date(row.created_at).toISOString()
  })).toString('base64url');
  const signature = createHmac('sha256', secret).update(payload).digest('base64url');
  return `${payload}.${signature}`;
}

app.get('/health', async (_req, res) => {
  try {
    await getPool().query('SELECT 1');
    res.status(200).json({ status: 'ok' });
  } catch {
    res.status(503).json({ status: 'not_ready' });
  }
});

app.get('/api/event', async (_req, res) => {
  try {
    const { event, tickets } = await getEventAndTicketRows({ activeOnly: true });
    res.setHeader('Cache-Control', 'no-store');
    return res.json({ event, tickets });
  } catch (error) {
    console.error('Ticketübersicht konnte nicht geladen werden:', error.message);
    return res.status(503).json({ error: 'Die Ticketinformationen sind gerade nicht verfügbar.' });
  }
});

app.post('/api/reservations', async (req, res) => {
  const fullName = cleanText(req.body?.name, 180);
  const email = normalizeEmail(req.body?.email);
  const requestKey = String(req.body?.requestKey || '');
  const requestedItems = req.body?.items;
  if (fullName.length < 2) return res.status(400).json({ error: 'Bitte gib deinen Namen ein.' });
  if (!validEmail(email)) return res.status(400).json({ error: 'Bitte gib eine gültige E-Mail-Adresse ein.' });
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(requestKey)) {
    return res.status(400).json({ error: 'Die Reservierung konnte nicht sicher zugeordnet werden. Bitte lade die Seite neu.' });
  }
  if (!Array.isArray(requestedItems) || requestedItems.length < 1 || requestedItems.length > 2) {
    return res.status(400).json({ error: 'Bitte wähle mindestens ein Ticket aus.' });
  }

  const ids = requestedItems.map((item) => String(item?.ticketTypeId || ''));
  const quantities = requestedItems.map((item) => Number(item?.quantity));
  if (new Set(ids).size !== ids.length || ids.some((id) => !['abend-1', 'abend-2'].includes(id)) ||
      quantities.some((quantity) => !Number.isInteger(quantity) || quantity < 1 || quantity > 10) ||
      quantities.reduce((sum, quantity) => sum + quantity, 0) > 10) {
    return res.status(400).json({ error: 'Die Ticket-Auswahl ist ungültig. Pro Reservierung sind maximal 10 Tickets möglich.' });
  }

  const pool = getPool();
  let reservationId;
  let event;
  let tickets;
  let totalCents = 0;
  try {
    const existing = await findExistingReservation(pool, requestKey, email);
    if (existing) return res.status(existing.status).json(existing.body);
    const retryAfter = reservationRateLimit(email);
    if (retryAfter) {
      res.setHeader('Retry-After', String(retryAfter));
      return res.status(429).json({ error: 'Zu viele Reservierungen in kurzer Zeit. Bitte warte etwas und versuche es später erneut.' });
    }

    const placeholders = ids.map(() => '?').join(',');
    const [selectedRows] = await pool.execute(
      `SELECT id, name, description, price_cents FROM ticket_types
       WHERE id IN (${placeholders}) AND is_active = 1`,
      ids
    );
    if (selectedRows.length !== ids.length) {
      return res.status(400).json({ error: 'Ein ausgewähltes Ticket ist nicht mehr verfügbar.' });
    }
    const [eventRows] = await pool.execute(
      'SELECT event_title, event_date, school_name, event_location, visitor_instructions FROM ticket_event_settings WHERE id = 1'
    );
    if (!eventRows.length) return res.status(503).json({ error: 'Die Veranstaltung ist noch nicht eingerichtet.' });
    event = eventFromRow(eventRows[0]);

    const byId = new Map(selectedRows.map((row) => [row.id, row]));
    tickets = [];
    for (let index = 0; index < ids.length; index += 1) {
      const row = byId.get(ids[index]);
      const priceCents = Number(row.price_cents);
      if (!Number.isSafeInteger(priceCents) || priceCents < 0) {
        return res.status(503).json({ error: 'Der Ticketpreis ist ungültig. Bitte wende dich an die Veranstaltungsleitung.' });
      }
      totalCents += priceCents * quantities[index];
      for (let count = 0; count < quantities[index]; count += 1) {
        tickets.push({
          ticketCode: newTicketCode(),
          ticketTypeId: row.id,
          ticketName: row.name,
          ticketDescription: row.description,
          priceCents,
          eventSnapshot: event
        });
      }
    }
    if (!Number.isSafeInteger(totalCents) || tickets.length < 1 || tickets.length > 10) {
      return res.status(400).json({ error: 'Pro Reservierung sind maximal 10 Tickets möglich.' });
    }

    reservationId = requestKey;
    const connection = await pool.getConnection();
    let duplicateReservationInsert = false;
    try {
      await connection.beginTransaction();
      const [eventLockRows] = await connection.execute(
        'SELECT id FROM ticket_event_settings WHERE id = 1 FOR UPDATE'
      );
      if (eventLockRows.length !== 1) throw new Error('Die Veranstaltungsdaten sind nicht initialisiert.');
      try {
        await connection.execute(
          `INSERT INTO ticket_reservations
           (id, full_name, email, total_cents, status, event_snapshot, email_status)
           VALUES (?, ?, ?, ?, 'reserved', ?, 'not_sent')`,
          [reservationId, fullName, email, totalCents, JSON.stringify(event)]
        );
      } catch (error) {
        if (error.code === 'ER_DUP_ENTRY' || error.errno === 1062) duplicateReservationInsert = true;
        throw error;
      }
      for (const ticket of tickets) {
        await connection.execute(
          `INSERT INTO ticket_instances
           (ticket_code, reservation_id, ticket_type_id, ticket_name, ticket_description, price_cents, event_snapshot)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [ticket.ticketCode, reservationId, ticket.ticketTypeId, ticket.ticketName,
            ticket.ticketDescription, ticket.priceCents, JSON.stringify(ticket.eventSnapshot)]
        );
      }
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      if (!duplicateReservationInsert) throw error;
    } finally {
      connection.release();
    }
    if (duplicateReservationInsert) {
      const existing = await findExistingReservation(pool, requestKey, email);
      if (existing) {
        releaseReservationRateLimit(email);
        return res.status(existing.status).json(existing.body);
      }
      throw new Error('Eine Reservierung mit dieser ID konnte nicht eindeutig gelesen werden.');
    }

    const responseTickets = tickets.map(({ ticketCode, ticketTypeId, ticketName, ticketDescription, priceCents }) =>
      ({ ticketCode, ticketTypeId, ticketName, ticketDescription, priceCents }));
    return res.status(201).json({
      reservationId,
      emailStatus: 'not_sent',
      tickets: responseTickets,
      event,
      totalCents
    });
  } catch (error) {
    console.error('Ticketreservierung konnte nicht gespeichert werden:', error.message);
    return res.status(503).json({ error: 'Die Reservierung konnte gerade nicht gespeichert werden. Bitte versuche es erneut.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  let origin;
  try {
    origin = publicOriginFromClient(req, req.body?.origin);
  } catch {
    return res.status(400).json({ error: 'Die sichere Shop-Adresse konnte nicht bestätigt werden.' });
  }

  const allowedEmail = normalizeEmail(process.env.TICKET_ADMIN_EMAIL);
  const expectedPassword = String(process.env.TICKET_ADMIN_PASSWORD || '');
  if (!validEmail(allowedEmail) || expectedPassword.length < 12) {
    return res.status(503).json({ error: 'Die Admin-Anmeldung ist noch nicht vollständig eingerichtet.' });
  }

  const email = normalizeEmail(req.body?.email);
  const candidatePassword = typeof req.body?.password === 'string' ? req.body.password : '';
  const retryAfter = adminLoginWait(req, email || 'invalid');
  if (retryAfter) {
    res.setHeader('Retry-After', String(retryAfter));
    return res.status(429).json({ error: 'Zu viele fehlgeschlagene Anmeldeversuche.' });
  }

  const passwordMatches = passwordsMatch(candidatePassword.slice(0, 512), expectedPassword);
  if (!validEmail(email) || email !== allowedEmail || !candidatePassword || candidatePassword.length > 512 || !passwordMatches) {
    const wait = recordAdminLoginFailure(req, email || 'invalid');
    if (wait) res.setHeader('Retry-After', String(wait));
    return res.status(wait ? 429 : 401).json({ error: 'E-Mail-Adresse oder Passwort stimmen nicht.' });
  }

  try {
    const openId = `email-password:${allowedEmail}`;
    const name = 'Administrator';
    await upsertAdminUser(openId, allowedEmail, name);
    const session = createAppSession({ openId, email: allowedEmail, name });
    setAppSessionCookie(res, session.token, origin);
    clearAdminLoginFailures(req, email);
    return res.json({ authenticated: true });
  } catch {
    return res.status(503).json({ error: 'Die Admin-Anmeldung ist gerade nicht verfügbar.' });
  }
});

app.post('/api/auth/start', async (req, res) => {
  try {
    const origin = publicOriginFromClient(req, req.body?.origin);
    if (!process.env.MANUS_OAUTH_PORTAL_URL || !process.env.MANUS_PROJECT_ID) {
      return res.status(503).json({ error: 'Die Manus-Anmeldung ist nicht verfügbar.' });
    }
    const redirectUri = `${origin}/auth/callback`;
    const nonce = randomUUID();
    const state = { redirectUri, nonce };
    setOAuthStateCookie(res, { redirectUri, nonce, origin }, origin);

    const portalBase = process.env.MANUS_OAUTH_PORTAL_URL.replace(/\/+$/, '');
    const authorizationUrl = new URL(`${portalBase}/app-auth`);
    authorizationUrl.searchParams.set('appId', process.env.MANUS_PROJECT_ID);
    authorizationUrl.searchParams.set('redirectUri', redirectUri);
    authorizationUrl.searchParams.set('state', Buffer.from(JSON.stringify(state)).toString('base64'));
    authorizationUrl.searchParams.set('responseType', 'code');
    return res.json({ authorizationUrl: authorizationUrl.toString() });
  } catch (error) {
    return res.status(400).json({ error: error.message || 'Die Anmeldung konnte nicht gestartet werden.' });
  }
});

app.get('/auth/callback', async (req, res) => {
  const stateCookie = readOAuthStateCookie(req);
  let state;
  try { state = JSON.parse(Buffer.from(String(req.query.state || ''), 'base64').toString('utf8')); } catch { state = null; }
  const origin = stateCookie?.origin;
  if (origin) clearOAuthStateCookie(res, origin);

  if (!stateCookie || !state || !req.query.code ||
      state.nonce !== stateCookie.nonce || state.redirectUri !== stateCookie.redirectUri ||
      `${state.redirectUri}` !== `${stateCookie.origin}/auth/callback`) {
    return res.redirect('/admin?error=state');
  }

  const configuredEmail = normalizeEmail(process.env.TICKET_ADMIN_EMAIL);
  const oauthApi = String(process.env.MANUS_OAUTH_API_URL || '').replace(/\/+$/, '');
  if (!configuredEmail || !oauthApi) return res.redirect('/admin?error=setup');

  try {
    const tokenResponse = await fetch(`${oauthApi}/webdev.v1.WebDevAuthPublicService/ExchangeToken`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        clientId: process.env.MANUS_PROJECT_ID,
        grantType: 'authorization_code',
        code: String(req.query.code),
        redirectUri: state.redirectUri
      }),
      signal: AbortSignal.timeout(15000)
    });
    if (!tokenResponse.ok) return res.redirect('/admin?error=oauth');
    const tokenData = await tokenResponse.json();
    if (!tokenData?.accessToken) return res.redirect('/admin?error=oauth');

    const userResponse = await fetch(`${oauthApi}/webdev.v1.WebDevAuthPublicService/GetUserInfo`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ accessToken: tokenData.accessToken }),
      signal: AbortSignal.timeout(15000)
    });
    if (!userResponse.ok) return res.redirect('/admin?error=oauth');
    const user = await userResponse.json();
    const email = normalizeEmail(user?.email);
    const openId = String(user?.openId || '');
    const name = cleanText(user?.name, 255);
    if (!openId || !validEmail(email)) return res.redirect('/admin?error=oauth');
    if (email !== configuredEmail) return res.redirect('/admin?error=not-admin');

    await upsertAdminUser(openId, email, name);
    const session = createAppSession({ openId, email, name });
    setAppSessionCookie(res, session.token, origin);
    return res.redirect('/admin');
  } catch {
    return res.redirect('/admin?error=oauth');
  }
});

app.get('/api/admin/me', async (req, res) => {
  const user = await getAdminContext(req, res, { allowRefresh: true });
  if (!user) return;
  return res.json({ authenticated: true, name: user.name, email: user.email, csrfToken: user.csrfToken });
});

app.post('/api/admin/logout', async (req, res) => {
  const user = await getAdminContext(req, res, { csrf: true });
  if (!user) return;
  const origin = getPublicOriginHeader(req);
  if (origin) clearAppSessionCookie(res, origin);
  return res.json({ ok: true });
});

app.get('/api/admin/dashboard', async (req, res) => {
  const user = await getAdminContext(req, res);
  if (!user) return;
  try {
    const pool = getPool();
    const [{ event, tickets }] = [await getEventAndTicketRows()];
    const cursor = parseReservationCursor(req.query.cursor);
    if (cursor === false) {
      return res.status(400).json({ error: 'Die Bestellseite ist ungültig.' });
    }
    const where = cursor ? 'WHERE (created_at < ? OR (created_at = ? AND id < ?))' : '';
    const parameters = cursor ? [cursor.createdAt, cursor.createdAt, cursor.id] : [];
    const [fetchedRows] = await pool.execute(
      `SELECT id, full_name, email, total_cents, status, event_snapshot, email_status, created_at
       FROM ticket_reservations ${where} ORDER BY created_at DESC, id DESC LIMIT 51`,
      parameters
    );
    const hasMore = fetchedRows.length > 50;
    const reservationRows = fetchedRows.slice(0, 50);
    let ticketRows = [];
    if (reservationRows.length) {
      const ids = reservationRows.map((row) => row.id);
      const placeholders = ids.map(() => '?').join(',');
      const [rows] = await pool.execute(
        `SELECT ticket_code, reservation_id, ticket_type_id, ticket_name, ticket_description, price_cents
         FROM ticket_instances WHERE reservation_id IN (${placeholders}) ORDER BY created_at, ticket_code`,
        ids
      );
      ticketRows = rows;
    }
    const ticketsByReservation = new Map();
    for (const row of ticketRows) {
      const list = ticketsByReservation.get(row.reservation_id) || [];
      list.push({
        ticketCode: row.ticket_code,
        ticketTypeId: row.ticket_type_id,
        ticketName: row.ticket_name,
        ticketDescription: row.ticket_description,
        priceCents: Number(row.price_cents)
      });
      ticketsByReservation.set(row.reservation_id, list);
    }
    const reservations = reservationRows.map((row) => ({
      id: row.id,
      fullName: row.full_name,
      email: row.email,
      totalCents: Number(row.total_cents),
      status: row.status,
      emailStatus: row.email_status,
      createdAt: row.created_at,
      tickets: ticketsByReservation.get(row.id) || []
    }));
    const lastReservation = reservationRows.at(-1);
    const nextCursor = hasMore && lastReservation ? createReservationCursor(lastReservation) : null;
    return res.json({ user: { name: user.name, email: user.email }, event, tickets, reservations, hasMore, nextCursor });
  } catch (error) {
    console.error('Admin-Übersicht konnte nicht geladen werden:', error.message);
    return res.status(503).json({ error: 'Die Verwaltung ist gerade nicht verfügbar.' });
  }
});

app.post('/api/admin/reset-reservations', async (req, res) => {
  const user = await getAdminContext(req, res, { csrf: true });
  if (!user) return;
  if (req.body?.confirmationPhrase !== 'ALLE RESERVIERUNGEN LÖSCHEN') {
    return res.status(400).json({ error: 'Der Bestätigungstext stimmt nicht überein. Es wurde nichts gelöscht.' });
  }

  let connection;
  let transactionStarted = false;
  try {
    connection = await getPool().getConnection();
    await connection.beginTransaction();
    transactionStarted = true;

    const [eventRows] = await connection.execute(
      'SELECT id FROM ticket_event_settings WHERE id = 1 FOR UPDATE'
    );
    if (eventRows.length !== 1) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(503).json({ error: 'Die Veranstaltung ist nicht initialisiert. Es wurde nichts gelöscht.' });
    }

    const [deletedTickets] = await connection.execute('DELETE FROM ticket_instances');
    const [deletedReservations] = await connection.execute('DELETE FROM ticket_reservations');
    await connection.commit();
    transactionStarted = false;

    return res.json({
      ok: true,
      deletedTickets: Number(deletedTickets.affectedRows || 0),
      deletedReservations: Number(deletedReservations.affectedRows || 0)
    });
  } catch (error) {
    if (connection && transactionStarted) {
      try { await connection.rollback(); } catch { /* Preserve the original transaction failure. */ }
    }
    console.error('Admin-Reset der Reservierungen fehlgeschlagen:', error.message);
    return res.status(503).json({ error: 'Der Reset konnte nicht bestätigt werden. Prüfe die Bestellliste, bevor du es erneut versuchst.' });
  } finally {
    connection?.release();
  }
});

app.put('/api/admin/save-all', async (req, res) => {
  const user = await getAdminContext(req, res, { csrf: true });
  if (!user) return;

  const eventInput = req.body?.event;
  const rawTickets = req.body?.tickets;
  if (!eventInput || typeof eventInput !== 'object' || Array.isArray(eventInput) || !Array.isArray(rawTickets) || rawTickets.length !== 2) {
    return res.status(400).json({ error: 'Bitte prüfe die Veranstaltungsangaben und beide Ticketarten.' });
  }

  const event = {
    eventTitle: cleanText(eventInput.eventTitle, 180),
    eventDate: cleanText(eventInput.eventDate, 180),
    schoolName: cleanText(eventInput.schoolName, 180),
    eventLocation: cleanText(eventInput.eventLocation, 255),
    visitorInstructions: cleanText(eventInput.visitorInstructions, 5000)
  };
  if (event.eventTitle.length < 2) {
    return res.status(400).json({ error: 'Bitte gib einen Veranstaltungstitel ein.' });
  }

  const allowedTicketIds = ['abend-1', 'abend-2'];
  const seenTicketIds = new Set();
  const tickets = [];
  for (const input of rawTickets) {
    const id = String(input?.id || '');
    const name = cleanText(input?.name, 120);
    const description = cleanText(input?.description, 3000);
    const priceCents = input?.priceCents;
    if (!allowedTicketIds.includes(id) || seenTicketIds.has(id)) {
      return res.status(400).json({ error: 'Bitte prüfe die beiden Ticketarten.' });
    }
    if (name.length < 2 || typeof priceCents !== 'number' || !Number.isSafeInteger(priceCents) || priceCents < 0 || priceCents > 1000000 || typeof input?.isActive !== 'boolean') {
      return res.status(400).json({ error: 'Bitte prüfe Ticketname, Preis und Verfügbarkeit.' });
    }
    seenTicketIds.add(id);
    tickets.push({ id, name, description, priceCents, isActive: input.isActive });
  }
  if (allowedTicketIds.some((id) => !seenTicketIds.has(id))) {
    return res.status(400).json({ error: 'Bitte übermittle beide Ticketarten.' });
  }

  let connection;
  let transactionStarted = false;
  try {
    connection = await getPool().getConnection();
    await connection.beginTransaction();
    transactionStarted = true;

    const [eventRows] = await connection.execute(
      'SELECT id FROM ticket_event_settings WHERE id = 1 FOR UPDATE'
    );
    const [ticketRows] = await connection.execute(
      'SELECT id FROM ticket_types WHERE id IN (?, ?) FOR UPDATE',
      allowedTicketIds
    );
    if (eventRows.length !== 1 || ticketRows.length !== allowedTicketIds.length) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(503).json({ error: 'Veranstaltung oder Ticketdaten sind nicht initialisiert.' });
    }

    await connection.execute(
      `UPDATE ticket_event_settings SET event_title = ?, event_date = ?, school_name = ?,
       event_location = ?, visitor_instructions = ? WHERE id = 1`,
      [event.eventTitle, event.eventDate, event.schoolName, event.eventLocation, event.visitorInstructions]
    );
    for (const ticket of tickets) {
      await connection.execute(
        `UPDATE ticket_types SET name = ?, description = ?, price_cents = ?, is_active = ? WHERE id = ?`,
        [ticket.name, ticket.description, ticket.priceCents, ticket.isActive ? 1 : 0, ticket.id]
      );
    }
    await connection.commit();
    transactionStarted = false;
    return res.json({ ok: true, updatedTickets: tickets.length });
  } catch (error) {
    if (connection && transactionStarted) {
      try { await connection.rollback(); } catch { /* Preserve the original transaction failure. */ }
    }
    console.error('Admin-Änderungen konnten nicht gemeinsam gespeichert werden:', error.message);
    return res.status(503).json({ error: 'Die Änderungen konnten nicht gemeinsam gespeichert werden. Bitte versuche es erneut.' });
  } finally {
    connection?.release();
  }
});

app.get('/', (_req, res) => res.sendFile(path.join(publicDir, 'index.html')));
app.get('/shop', (_req, res) => res.sendFile(path.join(publicDir, 'index.html')));
app.get('/bestaetigung', (_req, res) => res.sendFile(path.join(publicDir, 'confirmation.html')));
app.get('/admin', (_req, res) => res.sendFile(path.join(publicDir, 'admin.html')));
app.get('/rechtliches', (_req, res) => res.sendFile(path.join(publicDir, 'legal.html')));

const assetOptions = {
  maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0,
  etag: true
};
app.get('/manus-routes.json', (_req, res) => res.sendFile(path.join(publicDir, 'manus-routes.json')));
app.use('/css', express.static(path.join(publicDir, 'css'), assetOptions));
app.use('/js', express.static(path.join(publicDir, 'js'), assetOptions));
app.use('/images', express.static(path.join(publicDir, 'images'), assetOptions));
app.use((_req, res) => res.status(404).sendFile(path.join(publicDir, '404.html')));

async function start() {
  await runMigrations();
  app.listen(port, '0.0.0.0', () => console.log(`Ticketshop hört auf Port ${port}.`));
}

start().catch((error) => {
  console.error('Ticketshop konnte nicht gestartet werden:', error.message);
  process.exit(1);
});
