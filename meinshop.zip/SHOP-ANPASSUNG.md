# Ticketshop BEERCHHAIN U-CLUB HEEK

Der Shop verwendet das gelieferte Schwarz-Weiß-Logo von **BEERCHHAIN U-CLUB HEEK**: geometrisches Signet, kräftige Blockschrift und kontrastreiche Ticketkarten. Die Veranstaltung bietet zwei Ticketarten — **Abend 1** und **Abend 2** — zum Startpreis von **5 € je Ticket**. Es gibt keine Onlinezahlung und keine Bestätigungsmail.

## Veranstaltung und Tickets ändern

Öffne im Shop den Link **Verwaltung** oder rufe `/admin` auf. Der Verwaltungslink öffnet einen eigenen Tab. Melde dich mit der Besitzer-E-Mail und dem persönlichen Passwort an. Beide Werte werden über die geschützte Projekteingabe gesetzt; das Passwort wird nicht im Shopcode oder in dieser Anleitung gespeichert. Nur diese E-Mail-/Passwort-Kombination kann Tickets und Veranstaltungsangaben bearbeiten. Die Anmeldung begrenzt Fehlversuche und verwendet eine sichere, für eingebettete Vorschau-Kontexte vorbereitete Sitzung. Falls eine Vorschau im Dashboard eingebettet ist und der Browser das Sitzungscookie blockiert, nutze **Verwaltung in neuem Tab öffnen**.

Unter **Veranstaltung** kannst du Titel, Datum/Uhrzeit, Schule, Ort/Treffpunkt und Besuchshinweise ergänzen. Unter **Tickets bearbeiten** kannst du Namen, Beschreibungen, Preise und Aktivierung der zwei Ticketarten ändern. Wenn alles stimmt, scrolle bis zum schwarzen Balken **Änderungen übernehmen** und klicke einmal auf **Änderungen speichern**. So werden die Veranstaltungsangaben und beide Ticketarten gemeinsam gespeichert; vor dem Klick bleiben Änderungen nur im Formular. Bei Erfolg bestätigt eine Meldung das Speichern, und die Shopseite zeigt nach dem Neuladen die neuen Angaben. Bei einem Fehler bleiben deine Eingaben erhalten. Bereits reservierte Tickets behalten ihre damaligen Angaben; neue Reservierungen verwenden die gespeicherten Änderungen.

Unter **Bestellungen** siehst du Name, E-Mail-Adresse und Ticketnummern. Neue Bestellungen sind mit **Screenshot statt E-Mail** markiert; es gibt keinen Mailversand- oder Resend-Button. Ältere Einträge kannst du über **Ältere Bestellungen laden** nachladen. Pro Reservierung sind höchstens 10 Tickets zulässig.

Im Bereich **Dauerhafter Reset** kannst du sämtliche Reservierungen leeren. Dabei werden Ticketnummern und alle gespeicherten Namen sowie E-Mail-Adressen **endgültig gelöscht**; das lässt sich nicht rückgängig machen. Zur Freigabe musst du im Bestätigungsdialog exakt `ALLE RESERVIERUNGEN LÖSCHEN` eingeben und anschließend **Endgültig löschen** wählen. Veranstaltungstitel, Veranstaltungsdaten, Ticketarten und Preise bleiben erhalten; neue Reservierungen sind danach weiterhin möglich. Die Reset-Funktion löscht nichts, solange du sie nicht selbst im Adminbereich bestätigst.

## Reservierung und Anmeldung

Nach einer Reservierung werden die Ticketnummern direkt auf der Bestätigungsseite angezeigt. Dort fordert ein auffälliger Hinweis dazu auf, sofort einen Screenshot zu machen und ihn beim Einlass zu zeigen. Eine Bestätigungsmail wird nicht versendet. Wenn der Browser die Seite nicht öffnen kann, versucht der Shop, die Tickets direkt auf der Buchungsseite anzuzeigen. Name und E-Mail-Adresse bleiben in der Admin-Bestellliste sichtbar; ergänze vor dem Verkauf die passenden Datenschutzhinweise.

Die Besitzer-E-Mail und das Passwort für den Admin-Login sind ausschließlich über geschützte Projekteingaben konfiguriert. Der Besitzer-Login und der geschützte Zugriff auf die Verwaltung wurden erfolgreich in der Vorschau geprüft.

Die Anmeldung akzeptiert nur die aktuelle Vorschau sowie serverseitig freigegebene öffentliche Origins. Der Preview-Proxy kann den Request-Origin auf seinen internen HTTP-Listener umschreiben; dieser wird nur akzeptiert, wenn `X-Public-Origin` exakt zur freigegebenen Vorschau passt. Für eine eigene Domain muss deren HTTPS-Origin vor dem Livegang freigeschaltet werden.

## Vor einem echten Verkauf ergänzen

Trage Titel, Datum/Uhrzeit, Schule, Treffpunkt und Besuchshinweise im Adminbereich ein, sobald sie feststehen. Bis dahin zeigt der Shop „Wird noch ergänzt“ statt erfundener Daten. Ergänze außerdem die Veranstalter- und Datenschutzangaben unter **Hinweise**; diese rechtliche Seite ist derzeit ein Platzhalter.

Es wurden keine Testbestellungen, Test-E-Mails, Teständerungen an Veranstaltungs- und Ticketdaten oder Reset-Aktionen ausgeführt. Die Datenbank ist zwischen Vorschau und Veröffentlichung geteilt; eine bewusste Testreservierung, Teständerung oder ein Reset würde reale Daten betreffen.
