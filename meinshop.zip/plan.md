# Plan: Ticketverkauf für zwei Veranstaltungsabende

## Geltungsbereich

Dieser Plan ersetzt die bisherige Muster-Produkt-/Stripe-Checkout-Idee. Die Website ist jetzt ein schlichter Ticketverkauf für genau zwei Ticketarten: ein Ticket für den ersten Abend und eines für den zweiten Abend. Der angezeigte Startpreis beträgt für beide Arten **5 € je Ticket**. Es findet **keine Onlinezahlung** statt.

Besucher wählen Ticketart und Anzahl, geben Name und E-Mail-Adresse an und senden eine Reservierung ab. Für jedes reservierte Ticket wird eine eigene digitale Ticketkarte mit eindeutiger Ticketnummer erzeugt und direkt auf der Bestätigungsseite angezeigt. **Es wird keine Bestätigungsmail versendet.** Die Bestätigungsseite fordert dazu auf, sofort einen Screenshot mit den Ticketnummern zu machen und diese beim Einlass vorzuzeigen. Solange Datum oder Ort noch nicht gepflegt sind, zeigt die Website „Wird noch ergänzt“ statt erfundener Daten. Die E-Mail-Adresse bleibt als Zuordnungs- und Kontaktangabe in der geschützten Reservierungsverwaltung gespeichert.

Der Administrator kann Ticketnamen, Beschreibungen, Preise und Aktivstatus sowie den Veranstaltungstitel, die Datums-/Zeitangabe, Schule/Ort und zusätzliche Hinweise bearbeiten. Ein einziger Button „Änderungen speichern“ am Ende dieses Bearbeitungsbereichs speichert den gesamten Veranstaltungssatz und beide Ticketarten in einer authentifizierten, CSRF-geschützten Datenbanktransaktion. Erst nach Commit werden die neuen Werte im öffentlichen Shop angezeigt; fehlerhafte oder teilweise Eingaben dürfen keinen Teilsatz veröffentlichen. Die Bestellübersicht enthält die Ticketnummern; für neue Reservierungen kennzeichnet sie, dass kein Mailversand erfolgt und der Screenshot der Bestätigungsseite die Ticketkopie ist.

Zusätzlich kann der angemeldete Administrator im Bereich „Bestellungen“ **alle Reservierungen endgültig löschen**, einschließlich Ticketnummern, Namen und E-Mail-Adressen. Ein deutlich sichtbarer Warnhinweis nennt diese Folgen; das Löschfeld wird erst freigegeben, nachdem der Administrator `ALLE RESERVIERUNGEN LÖSCHEN` exakt eingetippt hat. Die Löschung betrifft keine Veranstaltungsangaben, Ticketarten oder Preise; danach sind neue Reservierungen weiterhin möglich. Serverseitig ist der Endpunkt sitzungs- und CSRF-geschützt und löscht Reservierungen samt Ticketinstanzen atomar. Die Reservierungsanlage und der Reset sperren dieselbe Veranstaltungszeile, damit konkurrierende Buchungen eindeutig vor oder nach dem Reset liegen. Die Implementierung führt keinen Reset aus.

## Umsetzung und Abhängigkeiten

Die flexible Node-/Express-Anwendung und verwaltete MySQL-Datenbank werden weiterverwendet. Eine additive Migration legt Tickettypen, Veranstaltungsdaten, einzelne Tickets und historische Mailstatusfelder an; vorhandene Tabellen werden weder gelöscht noch überschrieben. Neue Reservierungen werden als „not_sent“ gespeichert. Der vollständige Reset verwendet InnoDB-Transaktion und `DELETE` statt `TRUNCATE`, lässt Ticket-/Veranstaltungsdaten stehen und gibt ausschließlich Summenzahlen zurück. Seed-Werte für die beiden Abende werden nur eingesetzt, wenn sie noch fehlen. Die verwaltete Datenbank ist zwischen Entwicklung und Veröffentlichung geteilt; in dieser Implementierung wurden keine Testreservierungen angelegt.

Der Stripe-Checkout, Stripe-Webhook, Browseraktionen und die Stripe-Paketabhängigkeit wurden aus der Website entfernt. Keine Ticket-API ruft Stripe auf; veraltete Checkout-Routen liefern 404. Die vorhandene projektseitige Stripe-Integration und deren verwaltete Konfiguration bleiben **unbenutzt** und haben keinen aktiven Bezug zum Ticketablauf. Eine separate Entfernung der Integration wurde nicht vorgenommen.

Der Adminbereich verwendet die vom Betreiber gewünschte E-Mail-/Passwort-Anmeldung statt einer Manus-Konto-Freigabe. Die Besitzer-E-Mail und das Passwort werden ausschließlich als geschützte Umgebungswerte konfiguriert und nicht in Projektdateien gespeichert. Nur exakt diese E-Mail plus das Passwort kann eine achtstündige, signierte und CSRF-geschützte Anwendungssitzung erhalten. HTTPS-Sitzungscookies sind `SameSite=None; Secure; Partitioned`, um eingebettete Preview-Kontexte mit Drittanbieter-Cookie-Schutz zu unterstützen. Nach dem Login prüft das Frontend die Session im selben Fenster, statt sofort die Seite neu zu laden; bei blockierten Cookies zeigt es einen verständlichen Hinweis und bietet den eigenständigen Tab an. Login-Endpunkte prüfen die Vorschau-Origin und begrenzen Fehlversuche; Admin-API-Zugriffe verlangen weiterhin eine gültige Sitzung. Wenn der Preview-Proxy den Browser-Origin zum internen HTTP-Listener rebasiert, wird das nur akzeptiert, wenn `X-Public-Origin` exakt der freigegebenen öffentlichen Vorschau entspricht. `Sec-Fetch-Site: cross-site` wird nicht allein abgewiesen, weil die Vorschau in einem Dashboard-Iframe eingebettet ist. Die tatsächlichen Werte werden vom Betreiber über die geschützte Eingabemaske bereitgestellt.

Resend-Konfiguration und frühere Mailvorlagen bleiben als unbenutzter Altbestand im Projekt erhalten. Der Reservierungsablauf ruft den E-Mail-Anbieter nicht mehr auf; es gibt auch keinen Admin-Button zum erneuten Versand. Für den gewünschten Screenshot-Abschluss ist keine Absenderverifizierung erforderlich.

## Projektstruktur

- `server.js`: öffentliche Ticket-/Reservierungsrouten, Manus-OAuth-Callback und Admin-API; neue Reservierungen lösen keinen Mailversand aus.
- `src/db.js`, `src/migrations.js`, `migrations/`: Datenbankverbindung, additive Migrationen, Tickets und Reservierungen.
- `src/auth.js`: signierte Anwendungssitzung, Origin-/Cookie- und CSRF-Prüfungen.
- `src/ticket-mail.js`: frühere HTML-/Textmailvorlage; sie ist im aktuellen Reservierungsablauf nicht eingebunden.
- `public/`: Ticketübersicht, Bestätigungsseite, Admin-Anmeldung und -Verwaltung sowie gekennzeichnete Hinweis-Platzhalter.
- `public/js/`, `public/css/`: sichere DOM-Interaktionen und responsives Gestaltungssystem.
- `public/manus-routes.json`: deklarierte Website-Routen, keine API-Pfade.
- `SHOP-ANPASSUNG.md`: Bedien- und Einrichtungshinweise.

## Gestaltung

Die anfänglich verwendete warme Editorial-Gestaltung ist durch den vom Nutzer gelieferten BEERCHHAIN-Schwarz-Weiß-Stil ersetzt. Maßgeblich ist der Abschnitt „Marken-Stil: BEERCHHAIN U-CLUB HEEK“ am Ende dieses Plans; die aktuelle Reservierungsübergabe folgt dem Screenshot-Abschluss im Geltungsbereich.

## Noch offene Betreiber-Schritte

- Veranstaltungstitel, Datum/Uhrzeit, Schule, Treffpunkt und Besucherhinweise im Adminbereich ergänzen, sobald sie feststehen.
- Für den aktuellen Screenshot-Abschluss ist keine Resend-Absenderverifizierung erforderlich; der Anbieter wird vom Ticketablauf nicht aufgerufen.
- Vor öffentlichem Verkauf die Platzhalter unter „Hinweise“ um die erforderlichen Veranstalter-, Datenschutz- und Rechtstexte ergänzen.
- Der persönliche E-Mail-/Passwort-Login, das sichere Sitzungscookie und der geschützte Admin-Dashboardzugriff wurden über den öffentlichen Preview-Proxy erfolgreich geprüft. Die Vorschau rebasierte den Request-Origin auf den internen Listener; akzeptiert wird das nur mit passendem, freigegebenem `X-Public-Origin`. Vor einer Nutzung auf einer eigenen Produktionsdomain muss deren HTTPS-Origin serverseitig freigeschaltet werden.

## Besitzer-Login

- `TICKET_ADMIN_EMAIL` enthält ausschließlich die Admin-E-Mail-Adresse, die der Besitzer sicher eingibt.
- `TICKET_ADMIN_PASSWORD` enthält ausschließlich das zugehörige, mindestens 12 Zeichen lange Besitzerpasswort in der geschützten Projekt-Secrets-Verwaltung.
- Der Login liefert für falsche Zugangsdaten dieselbe Fehlermeldung, sperrt nach fünf Fehlversuchen für 15 Minuten und setzt bei Erfolg das bestehende sichere Anwendungssitzungs-Cookie.
- Die Anmeldung wird mit den vom Besitzer sicher eingegebenen Werten praktisch geprüft; Geheimnisse erscheinen weder im Chat noch in Projektdateien oder Logs.

## Referenzen zur unbenutzten früheren E-Mail-Integration

- Resend sendet HTML-/Text-E-Mails per `POST https://api.resend.com/emails` mit Bearer-API-Schlüssel; `from`, `to` und `subject` sind erforderlich. Die Dokumentation beschreibt Idempotenz-Schlüssel: https://resend.com/docs/api-reference/emails/send-email
- Resend verlangt eine verifizierte eigene Domain, bevor der Dienst aus dieser Domain sendet; DNS-Einträge wie DKIM/SPF müssen beim DNS-Anbieter gesetzt werden: https://resend.com/docs/add-a-domain

## Zusätzliche Schutz- und Betriebsregeln

- Die OAuth-Weiterleitung akzeptiert nur die beiden aktuellen Sandbox-/Preview-Origins sowie serverseitig konfigurierte `PUBLIC_APP_URL`- oder `TICKET_ALLOWED_ORIGINS`-Werte. Eine frei vom Browser übermittelte Origin wird nicht mehr vertraut. Vor einer späteren Veröffentlichung auf einer eigenen Domain muss deren Origin serverseitig freigeschaltet werden.
- Die vorhandene `ticket_reservations.id` ist ein UUID-Primärschlüssel und zugleich der Idempotenzschlüssel. So erzeugen Doppelklicks/Client-Retries keine zweite Reservierung, ohne eine weitere Datenbankmigration hinzuzufügen.
- Als Schutz vor Spam gelten höchstens 10 Tickets je Reservierung, drei neue Reservierungen pro normalisierter E-Mail-Adresse pro Stunde und 100 neue Reservierungen pro Shop-Prozess pro Stunde. Die Rate-Zähler liegen absichtlich nur im Arbeitsspeicher; nach einem Neustart beginnen sie neu.
- Die Admin-Bestellliste lädt 50 Reservierungen pro Seite und bietet „Ältere Bestellungen laden“, damit ältere Ticketcodes auffindbar bleiben.
- Historische Mailstatus älterer Reservierungen bleiben sichtbar. Für neue Reservierungen wird `not_sent` verwendet; der aktuelle Adminbereich bietet keinen Mailversand und keine Wiederholungsaktion.

## Abschließende Review-Korrekturen

- Admin-Seitencursor sind als Base64url-Payload plus HMAC-SHA256 mit dem projektseitigen Sitzungsschlüssel signiert und werden zeitkonstant geprüft. Der Parser akzeptiert nur UUID-v4-IDs und kanonische ISO-8601-Zeitstempel mit exaktem Round-Trip; frei konstruierte Cursor sind ungültig.
- Der idempotente Duplicate-Key-Fallback wird ausschließlich erfasst, wenn der Insert der Reservierungs-Primär-ID kollidiert. Ticketcode-Kollisionen bleiben normale Fehler und werden nicht als erfolgreiche Wiederholung fehlgedeutet. Für bestätigte Replay-Requests werden die zuvor dafür gebuchten Rate-Limit-Zähler zurückerstattet.

## Marken-Stil: BEERCHHAIN U-CLUB HEEK

- **Design Movement:** Minimalistische Club- und Sportidentität mit kräftiger, geometrischer Wortmarke; direkt an der gelieferten BEERCHHAIN-Logovorlage ausgerichtet.
- **Core Principles:** maximaler Schwarz-Weiß-Kontrast, klare Hierarchie, robuste Lesbarkeit, wenige präzise grafische Elemente.
- **Color Philosophy:** Weiß als saubere Bühne, tiefes Schwarz für Marke, Tickets und Aktionen; neutrale Grautöne nur für sekundäre Hinweise. Keine bisherigen warmen Beige-, Grün- oder Rosttöne.
- **Layout Paradigm:** asymmetrische, großzügig linksbündige Typografie mit klaren horizontalen Trennlinien; die beiden Ticketoptionen stehen als einfache, perforierte Ticketstreifen nebeneinander und stapeln sich auf Mobilgeräten.
- **Signature Elements:** die geometrische Klammer-/Rahmenmarke aus dem gelieferten Logo, kräftige Blockschrift und sparsame Perforations-/Schnittlinien auf den Tickets.
- **Interaction Philosophy:** schnörkellose Auswahl und Reservierung; schwarze Flächen markieren Hauptaktionen, Fokuszustände sind deutlich und zugänglich.
- **Animation:** nur kurze, dezente Hover-/Fokuswechsel; keine dauernde Bewegung; `prefers-reduced-motion` bleibt berücksichtigt.
- **Typography System:** geliefertes Logo als Bild ohne Änderung der Buchstabenformen; für Webtexte schwere System-Blockschrift (`Arial Black`, `Impact`, System-Fallback), im Lesetext eine neutrale System-Sans. Große Headlines in Versalien mit enger Laufweite.
- **Brand Essence:** Ticketshop von BEERCHHAIN U-CLUB HEEK für zwei Abende — markant, gemeinschaftlich, unkompliziert.
- **Brand Voice:** kurze, selbstbewusste Sätze. Beispiele: „Zwei Abende. Ein U-Club.“ und „Reservieren. Screenshot machen. Ticket beim Einlass zeigen.“
- **Wordmark & Logo:** das vom Nutzer gelieferte Schwarz-Weiß-Logo wird als Originalwortmarke eingesetzt; nur weiße Außenfläche wird transparent gemacht und großzügiger Leerraum wird zugeschnitten.
- **Signature Brand Color:** Schwarz `#050505`, gegen Weiß `#FFFFFF`.

Die Bestätigungsseite übernimmt die BEERCHHAIN-Wortmarke; Tickets und Screenshot-Hinweis bleiben als normaler Seitentext lesbar.
