import { runMigrations } from '../src/migrations.js';
import { getPool } from '../src/db.js';

try {
  await runMigrations();
  console.log('Shop-Datenbankschema ist bereit.');
} catch (error) {
  console.error('Migration fehlgeschlagen:', error.message);
  process.exitCode = 1;
} finally {
  if (process.env.DATABASE_URL) await getPool().end();
}
