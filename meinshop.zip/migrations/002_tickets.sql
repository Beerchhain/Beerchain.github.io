CREATE TABLE IF NOT EXISTS ticket_event_settings (
  id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  event_title VARCHAR(180) NOT NULL,
  event_date VARCHAR(180) NOT NULL DEFAULT '',
  school_name VARCHAR(180) NOT NULL DEFAULT '',
  event_location VARCHAR(255) NOT NULL DEFAULT '',
  visitor_instructions TEXT NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO ticket_event_settings
  (id, event_title, event_date, school_name, event_location, visitor_instructions)
VALUES
  (1, 'Schulabend', '', '', '', '');

CREATE TABLE IF NOT EXISTS ticket_types (
  id VARCHAR(32) NOT NULL PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  description TEXT NOT NULL,
  price_cents INT UNSIGNED NOT NULL DEFAULT 500,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order SMALLINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_ticket_types_active_order (is_active, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO ticket_types (id, name, description, price_cents, is_active, sort_order)
VALUES
  ('abend-1', 'Abend 1', 'Ticket für den ersten Veranstaltungsabend.', 500, 1, 1),
  ('abend-2', 'Abend 2', 'Ticket für den zweiten Veranstaltungsabend.', 500, 1, 2);

CREATE TABLE IF NOT EXISTS ticket_admin_users (
  open_id VARCHAR(255) NOT NULL PRIMARY KEY,
  email VARCHAR(320) NOT NULL,
  display_name VARCHAR(255) NOT NULL DEFAULT '',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_ticket_admin_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ticket_reservations (
  id CHAR(36) NOT NULL PRIMARY KEY,
  full_name VARCHAR(180) NOT NULL,
  email VARCHAR(320) NOT NULL,
  total_cents INT UNSIGNED NOT NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'reserved',
  event_snapshot JSON NOT NULL,
  email_status VARCHAR(24) NOT NULL DEFAULT 'not_sent',
  email_message_id VARCHAR(255) NULL,
  email_error_code VARCHAR(80) NULL,
  email_attempts INT UNSIGNED NOT NULL DEFAULT 0,
  email_sent_at TIMESTAMP NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_ticket_reservations_created (created_at),
  INDEX idx_ticket_reservations_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ticket_instances (
  ticket_code VARCHAR(20) NOT NULL PRIMARY KEY,
  reservation_id CHAR(36) NOT NULL,
  ticket_type_id VARCHAR(32) NOT NULL,
  ticket_name VARCHAR(120) NOT NULL,
  ticket_description TEXT NOT NULL,
  price_cents INT UNSIGNED NOT NULL,
  event_snapshot JSON NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_ticket_reservation_type_code (reservation_id, ticket_type_id, ticket_code),
  INDEX idx_ticket_instances_reservation (reservation_id),
  CONSTRAINT fk_ticket_instances_reservation FOREIGN KEY (reservation_id)
    REFERENCES ticket_reservations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
