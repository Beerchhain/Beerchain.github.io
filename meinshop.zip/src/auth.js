import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';

const SESSION_COOKIE = 'webdev_app_session';
const OAUTH_COOKIE = 'ticket_oauth_state';
const SESSION_SECONDS = 8 * 60 * 60;
const OAUTH_SECONDS = 10 * 60;
const PREVIEW_ORIGINS = new Set([
  'https://3000-is9vn8sda5620ehk8kgzp-0835caae.us3.manus.computer',
  'https://8328-is9vn8sda5620ehk8kgzp-0835caae.us3.manus.computer'
]);

function encodeJson(value) {
  return Buffer.from(JSON.stringify(value)).toString('base64url');
}

function decodeJson(value) {
  try {
    return JSON.parse(Buffer.from(value, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
}

function cookieFlags(origin, maxAge) {
  const isHttps = new URL(origin).protocol === 'https:';
  return `Path=/; HttpOnly; SameSite=${isHttps ? 'None' : 'Lax'}${isHttps ? '; Secure; Partitioned' : ''}; Max-Age=${maxAge}`;
}

function appSecret() {
  const secret = process.env.MANUS_JWT_SECRET;
  if (!secret) throw new Error('Die Manus-Sitzung ist nicht konfiguriert.');
  return secret;
}

function projectId() {
  const id = process.env.MANUS_PROJECT_ID;
  if (!id) throw new Error('Die Manus-Projekt-ID ist nicht konfiguriert.');
  return id;
}

function parseCookieHeader(header) {
  const result = new Map();
  for (const part of String(header || '').split(';')) {
    const separator = part.indexOf('=');
    if (separator < 0) continue;
    const name = part.slice(0, separator).trim();
    const value = part.slice(separator + 1).trim();
    if (!name) continue;
    try {
      result.set(name, decodeURIComponent(value));
    } catch {
      result.set(name, value);
    }
  }
  return result;
}

function configuredAllowedOrigins() {
  const origins = new Set(PREVIEW_ORIGINS);
  const candidates = [
    process.env.PUBLIC_APP_URL,
    ...(String(process.env.TICKET_ALLOWED_ORIGINS || '').split(','))
  ];
  for (const candidate of candidates) {
    try {
      const parsed = new URL(String(candidate || '').trim());
      if (!['https:', 'http:'].includes(parsed.protocol) || parsed.username || parsed.password) continue;
      if (parsed.pathname !== '/' || parsed.search || parsed.hash) continue;
      if (parsed.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(parsed.hostname)) continue;
      origins.add(parsed.origin);
    } catch {
      // Ignore malformed server configuration; unrecognized origins remain blocked.
    }
  }
  if (process.env.NODE_ENV !== 'production') {
    origins.add('http://localhost:3000');
    origins.add('http://127.0.0.1:3000');
  }
  return origins;
}

function isAllowedOrigin(origin) {
  return configuredAllowedOrigins().has(origin);
}

function isRebasedInternalRequestOrigin(req, requestOrigin) {
  try {
    const received = new URL(requestOrigin);
    const internal = new URL(`${req.protocol}://${req.get('host')}`);
    // Preview ingress rebases Origin to its internal HTTP listener; trust that only alongside the exact allowlisted X-Public-Origin.
    return received.protocol === 'http:'
      && ['localhost', '127.0.0.1'].includes(received.hostname)
      && received.origin === internal.origin;
  } catch {
    return false;
  }
}

function requestOriginMatches(req, expectedOrigin) {
  const requestOrigin = req.get('origin');
  if (!requestOrigin || requestOrigin === expectedOrigin) return true;
  return req.get('x-public-origin') === expectedOrigin
    && isRebasedInternalRequestOrigin(req, requestOrigin);
}

export function getCookie(req, name) {
  return parseCookieHeader(req.headers.cookie).get(name) || '';
}

export function publicOriginFromClient(req, candidate) {
  let parsed;
  try {
    parsed = new URL(String(candidate || ''));
  } catch {
    throw new Error('Die Browser-Adresse fehlt oder ist ungültig.');
  }
  if (!['https:', 'http:'].includes(parsed.protocol) || parsed.username || parsed.password) {
    throw new Error('Die Browser-Adresse muss eine gültige HTTPS-Adresse sein.');
  }
  if (parsed.pathname !== '/' || parsed.search || parsed.hash) {
    throw new Error('Es wird nur die Browser-Origin ohne Pfad akzeptiert.');
  }
  if (parsed.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(parsed.hostname)) {
    throw new Error('Für die Anmeldung ist HTTPS erforderlich.');
  }
  const origin = parsed.origin;
  if (!isAllowedOrigin(origin)) {
    throw new Error('Diese Shop-Domain ist nicht für die Anmeldung freigeschaltet.');
  }
  if (!requestOriginMatches(req, origin)) {
    throw new Error('Die Browser-Origin stimmt nicht mit der Anfrage überein.');
  }
  return origin;
}

export function setOAuthStateCookie(res, state, origin) {
  res.append('Set-Cookie', `${OAUTH_COOKIE}=${encodeURIComponent(encodeJson(state))}; ${cookieFlags(origin, OAUTH_SECONDS)}`);
}

export function clearOAuthStateCookie(res, origin) {
  res.append('Set-Cookie', `${OAUTH_COOKIE}=; ${cookieFlags(origin, 0)}`);
}

export function readOAuthStateCookie(req) {
  return decodeJson(getCookie(req, OAUTH_COOKIE));
}

export function createAppSession(identity) {
  const header = encodeJson({ alg: 'HS256', typ: 'JWT' });
  const now = Math.floor(Date.now() / 1000);
  const csrfToken = randomBytes(32).toString('base64url');
  const payload = encodeJson({
    appId: projectId(),
    openId: String(identity.openId),
    email: String(identity.email || '').trim().toLowerCase(),
    name: String(identity.name || ''),
    csrf: csrfToken,
    iat: now,
    exp: now + SESSION_SECONDS
  });
  const content = `${header}.${payload}`;
  const signature = createHmac('sha256', appSecret()).update(content).digest('base64url');
  return { token: `${content}.${signature}`, csrfToken };
}

export function setAppSessionCookie(res, token, origin) {
  res.append('Set-Cookie', `${SESSION_COOKIE}=${encodeURIComponent(token)}; ${cookieFlags(origin, SESSION_SECONDS)}`);
}

export function clearAppSessionCookie(res, origin) {
  res.append('Set-Cookie', `${SESSION_COOKIE}=; ${cookieFlags(origin, 0)}`);
}

export function verifyAppSession(req) {
  const token = getCookie(req, SESSION_COOKIE);
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  try {
    const content = `${parts[0]}.${parts[1]}`;
    const expected = createHmac('sha256', appSecret()).update(content).digest();
    const supplied = Buffer.from(parts[2], 'base64url');
    if (expected.length !== supplied.length || !timingSafeEqual(expected, supplied)) return null;
    const header = decodeJson(parts[0]);
    const payload = decodeJson(parts[1]);
    if (header?.alg !== 'HS256' || payload?.appId !== projectId()) return null;
    if (!Number.isFinite(payload.exp) || payload.exp <= Math.floor(Date.now() / 1000)) return null;
    if (typeof payload.openId !== 'string' || !payload.openId) return null;
    return payload;
  } catch {
    return null;
  }
}

export function getPublicOriginHeader(req) {
  const candidate = req.get('x-public-origin') || req.get('origin') || '';
  try {
    const parsed = new URL(candidate);
    if (!['https:', 'http:'].includes(parsed.protocol) || parsed.username || parsed.password) return '';
    if (parsed.pathname !== '/' || parsed.search || parsed.hash) return '';
    if (parsed.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(parsed.hostname)) return '';
    if (!requestOriginMatches(req, parsed.origin)) return '';
    if (!isAllowedOrigin(parsed.origin)) return '';
    return parsed.origin;
  } catch {
    return '';
  }
}

export function isValidCsrf(claims, supplied) {
  if (typeof claims?.csrf !== 'string' || typeof supplied !== 'string' || !supplied) return false;
  const left = Buffer.from(claims.csrf);
  const right = Buffer.from(supplied);
  return left.length === right.length && timingSafeEqual(left, right);
}
