import mysql from 'mysql2/promise';

let pool;

export function getPool() {
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL ist nicht konfiguriert.');
  }
  if (!pool) {
    // Der verwaltete DSN enthält die Verbindungs- und TLS-Parameter des Dienstes.
    pool = mysql.createPool(process.env.DATABASE_URL);
  }
  return pool;
}
