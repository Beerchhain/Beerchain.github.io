const BRAND = 'BEERCHHAIN U-CLUB HEEK';
const LOGO_URL = 'https://files.manuscdn.com/user_upload_by_module/session_file/310519664015023884/vPTnDaFGfuvZErgZ.png';

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[character]);
}

function formatPrice(cents) {
  return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(Number(cents || 0) / 100);
}

function eventLine(event, key, fallback) {
  const value = String(event?.[key] || '').trim();
  return value || fallback;
}

export function createTicketEmail({ fullName, event, tickets }) {
  const title = eventLine(event, 'eventTitle', 'Schulabend');
  const date = eventLine(event, 'eventDate', 'Wird noch ergänzt');
  const school = eventLine(event, 'schoolName', 'Wird noch ergänzt');
  const location = eventLine(event, 'eventLocation', '');
  const place = [school, location].filter(Boolean).join(' · ');
  const instructions = eventLine(event, 'visitorInstructions', 'Die Besuchshinweise werden noch ergänzt.');
  const ticketCards = tickets.map((ticket) => `
    <tr><td style="padding:0 0 14px">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:2px solid #050505;background:#ffffff">
        <tr><td style="padding:16px 18px 7px;font:900 12px Arial,sans-serif;letter-spacing:1.2px;color:#050505;text-transform:uppercase">${escapeHtml(ticket.ticketName)}</td>
          <td align="right" style="padding:16px 18px 7px;font:900 14px Arial,sans-serif;color:#050505">${formatPrice(ticket.priceCents)}</td></tr>
        <tr><td colspan="2" style="padding:0 18px 13px;font:13px/1.5 Arial,sans-serif;color:#333333">${escapeHtml(ticket.ticketDescription || '')}</td></tr>
        <tr><td colspan="2" style="padding:12px 18px;border-top:2px dashed #050505;font:700 14px/1.4 monospace;letter-spacing:1px;color:#050505">${escapeHtml(ticket.ticketCode)}</td></tr>
      </table>
    </td></tr>`).join('');

  const html = `<!doctype html><html lang="de"><body style="margin:0;background:#f0f0f0;color:#050505;font-family:Arial,sans-serif">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f0f0f0;padding:24px 10px"><tr><td align="center">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:620px;background:#ffffff;border:2px solid #050505;padding:26px">
        <tr><td style="padding:0 0 18px;border-bottom:2px solid #050505">
          <img src="${LOGO_URL}" width="160" alt="${BRAND}" style="display:block;width:160px;max-width:100%;height:auto;border:0">
        </td></tr>
        <tr><td style="padding:18px 0 7px;font:900 10px Arial,sans-serif;letter-spacing:2px;text-transform:uppercase;color:#050505">${BRAND} · TICKETRESERVIERUNG</td></tr>
        <tr><td style="font:900 28px/1.08 Arial,sans-serif;letter-spacing:-1px;text-transform:uppercase;color:#050505;padding-bottom:10px">Deine Tickets sind reserviert.</td></tr>
        <tr><td style="font:14px/1.7 Arial,sans-serif;color:#333333;padding-bottom:20px">Hallo ${escapeHtml(fullName)}, hier sind deine Tickets für <strong>${escapeHtml(title)}</strong>. Die Website nimmt keine Onlinezahlung entgegen.</td></tr>
        ${ticketCards}
        <tr><td style="padding:13px 0 6px;font:900 11px Arial,sans-serif;letter-spacing:1px;text-transform:uppercase;color:#050505">Wann und wo?</td></tr>
        <tr><td style="font:14px/1.7 Arial,sans-serif;color:#050505"><strong>Datum:</strong> ${escapeHtml(date)}<br><strong>Schule / Ort:</strong> ${escapeHtml(place)}</td></tr>
        <tr><td style="font:13px/1.7 Arial,sans-serif;color:#333333;padding:12px 0 18px">${escapeHtml(instructions)}</td></tr>
        <tr><td style="border-top:2px solid #050505;padding-top:13px;font:11px/1.6 Arial,sans-serif;color:#333333">Bewahre diese E-Mail auf und zeige dein Ticket bei Bedarf vor. Der Ticketpreis ist angegeben; bezahlt wird vor Ort. Online wurde nichts bezahlt.<br><br><strong>${BRAND}</strong></td></tr>
      </table>
    </td></tr></table>
  </body></html>`;

  const textTickets = tickets.map((ticket) => `${ticket.ticketName} · ${formatPrice(ticket.priceCents)}\n${ticket.ticketDescription || ''}\nTicketnummer: ${ticket.ticketCode}`).join('\n\n');
  const text = `${BRAND}\nTICKETRESERVIERUNG\n\nDeine Tickets sind reserviert.\n\nHallo ${fullName},\nhier sind deine Tickets für ${title}. Die Website nimmt keine Onlinezahlung entgegen.\n\n${textTickets}\n\nWann und wo?\nDatum: ${date}\nSchule / Ort: ${place}\n\n${instructions}\n\nBewahre diese E-Mail auf und zeige dein Ticket bei Bedarf vor. Der Ticketpreis ist angegeben; bezahlt wird vor Ort. Online wurde nichts bezahlt.`;
  return { subject: `${BRAND}: Deine Tickets für ${title}`, html, text };
}

export class TicketEmailError extends Error {
  constructor(code, message = 'Die Ticket-E-Mail konnte nicht versendet werden.', safeToRetry = false) {
    super(message);
    this.name = 'TicketEmailError';
    this.code = code;
    this.safeToRetry = safeToRetry;
  }
}

export async function sendTicketEmail({ reservationId, attempt, fullName, email, event, tickets }) {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.TICKET_FROM_EMAIL;
  if (!apiKey || !from || /[\r\n]/.test(from) || !from.includes('@')) {
    throw new TicketEmailError('mail_not_configured', 'Der E-Mail-Versand ist noch nicht vollständig konfiguriert.', true);
  }

  const content = createTicketEmail({ fullName, event, tickets });
  let response;
  try {
    response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'Idempotency-Key': `ticket-reservation-${reservationId}-attempt-${attempt}`
      },
      body: JSON.stringify({ from, to: [email], subject: content.subject, html: content.html, text: content.text }),
      signal: AbortSignal.timeout(15000)
    });
  } catch {
    throw new TicketEmailError('mail_network_error');
  }

  let result = {};
  try { result = await response.json(); } catch { /* Keep provider response bodies out of user-facing errors. */ }
  if (!response.ok) {
    const safeToRetry = response.status >= 400 && response.status < 500 && response.status !== 409;
    throw new TicketEmailError(`resend_http_${response.status}`, 'Die Ticket-E-Mail konnte nicht versendet werden.', safeToRetry);
  }
  if (!result.id) throw new TicketEmailError('resend_unknown_response');
  return result.id;
}
