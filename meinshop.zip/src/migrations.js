import { readdir, readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { getPool } from './db.js';

const migrationDir = fileURLToPath(new URL('../migrations/', import.meta.url));

async function listMigrations() {
  const files = await readdir(migrationDir);
  return files
    .map((name) => ({ name, match: name.match(/^(\d+)_.*\.sql$/) }))
    .filter((file) => file.match)
    .map((file) => ({ version: Number(file.match[1]), name: file.name }))
    .sort((a, b) => a.version - b.version);
}

export async function runMigrations() {
  const pool = getPool();
  const connection = await pool.getConnection();
  try {
    await connection.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version INT NOT NULL PRIMARY KEY,
        applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB
    `);

    for (const migration of await listMigrations()) {
      const [rows] = await connection.execute(
        'SELECT version FROM schema_migrations WHERE version = ?',
        [migration.version]
      );
      if (rows.length) continue;

      const sql = await readFile(path.join(migrationDir, migration.name), 'utf8');
      const statements = sql.split(/;\s*(?:\n|$)/).map((part) => part.trim()).filter(Boolean);
      for (const statement of statements) await connection.query(statement);
      await connection.execute('INSERT INTO schema_migrations (version) VALUES (?)', [migration.version]);
    }
  } finally {
    connection.release();
  }
}
