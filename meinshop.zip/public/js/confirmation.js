const title = document.querySelector('#confirmation-title');
const message = document.querySelector('#confirmation-message');
const screenshotPrompt = document.querySelector('#screenshot-prompt');
const ticketArea = document.querySelector('#confirmation-tickets');
const eventArea = document.querySelector('#confirmation-event');

function money(cents) {
  return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(Number(cents || 0) / 100);
}

function addText(parent, tag, className, value) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  element.textContent = value;
  parent.append(element);
  return element;
}

function render() {
  let reservation;
  try { reservation = JSON.parse(sessionStorage.getItem('ticketReservation') || 'null'); } catch { reservation = null; }
  if (!reservation || !Array.isArray(reservation.tickets) || !reservation.tickets.length) {
    title.textContent = 'Keine Ticketdetails in diesem Tab';
    message.textContent = 'Öffne diese Seite im selben Tab, in dem du reserviert hast. Es wird keine Bestätigungsmail versendet. Falls du den Tab bereits geschlossen hast, wende dich mit deinem Namen und deiner E-Mail-Adresse an die Veranstaltungsleitung.';
    return;
  }

  title.textContent = 'Deine Tickets sind reserviert.';
  message.textContent = 'Deine Reservierung ist gespeichert. Sichere die folgenden Ticketnummern jetzt als Screenshot.';
  screenshotPrompt.classList.remove('hidden');

  reservation.tickets.forEach((ticket) => {
    const card = document.createElement('article');
    card.className = 'confirmation-ticket';
    addText(card, 'h2', '', ticket.ticketName || 'Ticket');
    if (ticket.ticketDescription) addText(card, 'p', '', ticket.ticketDescription);
    addText(card, 'p', '', `${money(ticket.priceCents)} · keine Onlinezahlung`);
    const code = document.createElement('code');
    code.textContent = ticket.ticketCode;
    card.append(code);
    ticketArea.append(card);
  });

  const event = reservation.event || {};
  const date = event.eventDate || 'Wird noch ergänzt';
  const place = [event.schoolName, event.eventLocation].filter(Boolean).join(' · ') || 'Wird noch ergänzt';
  const instructions = event.visitorInstructions || 'Die Besuchshinweise werden noch ergänzt.';
  eventArea.textContent = '';
  addText(eventArea, 'strong', '', event.eventTitle || 'Schulabend');
  addText(eventArea, 'div', '', `Datum und Uhrzeit: ${date}`);
  addText(eventArea, 'div', '', `Schule / Ort: ${place}`);
  addText(eventArea, 'div', '', instructions);
  addText(eventArea, 'div', '', `Gesamtbetrag der Reservierung: ${money(reservation.totalCents)}. Auf dieser Website wurde nichts bezahlt.`);
}

render();
