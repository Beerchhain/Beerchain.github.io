const money = (cents) => new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(Number(cents || 0) / 100);
const ticketList = document.querySelector('#ticket-list');
const form = document.querySelector('#reservation-form');
const countSummary = document.querySelector('#selection-count');
const priceSummary = document.querySelector('#selection-total');
const submitButton = document.querySelector('#reservation-submit');
const status = document.querySelector('#reservation-status');
const reservationSection = document.querySelector('#reservieren');
const inlineConfirmation = document.querySelector('#inline-confirmation');
let availableTickets = [];

function setStatus(message, isError = false) {
  status.textContent = message;
  status.classList.toggle('error', isError);
}

function showEvent(event) {
  document.querySelector('#event-title').textContent = event.eventTitle || 'Schulabend';
  document.querySelector('#event-date').textContent = event.eventDate || 'Wird noch ergänzt';
  document.querySelector('#event-school').textContent = event.schoolName || 'Wird noch ergänzt';
  document.querySelector('#event-location').textContent = event.eventLocation || 'Wird noch ergänzt';
  document.querySelector('#event-instructions').textContent = event.visitorInstructions || 'Die Veranstaltungsangaben und Besuchshinweise werden ergänzt.';
}

function addConfirmationText(parent, tag, className, value) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  element.textContent = value;
  parent.append(element);
}

function renderInlineConfirmation(reservation) {
  const ticketArea = document.querySelector('#inline-confirmation-tickets');
  const eventArea = document.querySelector('#inline-confirmation-event');
  ticketArea.replaceChildren();
  reservation.tickets.forEach((ticket) => {
    const card = document.createElement('article');
    card.className = 'confirmation-ticket';
    addConfirmationText(card, 'h2', '', ticket.ticketName || 'Ticket');
    if (ticket.ticketDescription) addConfirmationText(card, 'p', '', ticket.ticketDescription);
    addConfirmationText(card, 'p', '', `${money(ticket.priceCents)} · keine Onlinezahlung`);
    addConfirmationText(card, 'code', '', ticket.ticketCode);
    ticketArea.append(card);
  });
  eventArea.replaceChildren();
  const event = reservation.event || {};
  addConfirmationText(eventArea, 'strong', '', event.eventTitle || 'Schulabend');
  addConfirmationText(eventArea, 'div', '', `Datum und Uhrzeit: ${event.eventDate || 'Wird noch ergänzt'}`);
  addConfirmationText(eventArea, 'div', '', `Schule / Ort: ${[event.schoolName, event.eventLocation].filter(Boolean).join(' · ') || 'Wird noch ergänzt'}`);
  addConfirmationText(eventArea, 'div', '', event.visitorInstructions || 'Die Besuchshinweise werden noch ergänzt.');
  addConfirmationText(eventArea, 'div', '', `Gesamtbetrag der Reservierung: ${money(reservation.totalCents)}. Auf dieser Website wurde nichts bezahlt.`);
  reservationSection.classList.add('hidden');
  inlineConfirmation.classList.remove('hidden');
  inlineConfirmation.scrollIntoView({ block: 'start' });
}

function selectedItems() {
  return [...document.querySelectorAll('.ticket-quantity')]
    .map((input) => ({ ticketTypeId: input.dataset.ticketId, quantity: Number(input.value) }))
    .filter((item) => Number.isInteger(item.quantity) && item.quantity > 0);
}

function updateSummary() {
  const items = selectedItems();
  const totalCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const totalCents = items.reduce((sum, item) => {
    const ticket = availableTickets.find((entry) => entry.id === item.ticketTypeId);
    return sum + (ticket ? ticket.priceCents * item.quantity : 0);
  }, 0);
  if (!items.length) {
    countSummary.textContent = 'Noch kein Ticket ausgewählt';
    priceSummary.textContent = money(0);
    submitButton.disabled = true;
    return;
  }
  const selectedNames = items.map((item) => {
    const ticket = availableTickets.find((entry) => entry.id === item.ticketTypeId);
    return `${item.quantity} × ${ticket?.name || 'Ticket'}`;
  });
  countSummary.textContent = `${totalCount} ${totalCount === 1 ? 'Ticket' : 'Tickets'} · ${selectedNames.join(' · ')}`;
  priceSummary.textContent = money(totalCents);
  if (totalCount > 10) {
    countSummary.textContent += ' · Maximal 10 je Reservierung';
    submitButton.disabled = true;
    return;
  }
  submitButton.disabled = false;
}

function renderTickets(tickets) {
  ticketList.replaceChildren();
  if (!tickets.length) {
    const empty = document.createElement('p');
    empty.className = 'muted';
    empty.textContent = 'Im Moment sind keine Tickets zur Reservierung freigeschaltet.';
    ticketList.append(empty);
    return;
  }
  tickets.forEach((ticket, index) => {
    const card = document.createElement('article');
    card.className = 'ticket-card';
    const number = document.createElement('div');
    number.className = 'ticket-number';
    number.setAttribute('aria-hidden', 'true');
    number.textContent = String(index + 1).padStart(2, '0');
    const copy = document.createElement('div');
    copy.className = 'ticket-copy';
    const name = document.createElement('h3');
    name.textContent = ticket.name;
    const description = document.createElement('p');
    description.textContent = ticket.description || 'Eintrittskarte für diesen Abend.';
    copy.append(name, description);
    const price = document.createElement('div');
    price.className = 'ticket-price';
    price.textContent = money(ticket.priceCents);
    const chooser = document.createElement('label');
    chooser.className = 'ticket-choose';
    const quantity = document.createElement('input');
    quantity.className = 'ticket-quantity';
    quantity.type = 'number';
    quantity.min = '0';
    quantity.max = '10';
    quantity.step = '1';
    quantity.value = '0';
    quantity.inputMode = 'numeric';
    quantity.dataset.ticketId = ticket.id;
    quantity.setAttribute('aria-label', `Anzahl für ${ticket.name}`);
    quantity.addEventListener('input', () => {
      const value = Math.max(0, Math.min(10, Math.floor(Number(quantity.value) || 0)));
      quantity.value = String(value);
      card.classList.toggle('ticket-card-selected', value > 0);
      updateSummary();
    });
    chooser.append(document.createTextNode('Anzahl'), quantity);
    card.append(number, copy, price, chooser);
    ticketList.append(card);
  });
  updateSummary();
}

async function loadEvent() {
  try {
    const response = await fetch('/api/event', { headers: { Accept: 'application/json' } });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Ticketinformationen konnten nicht geladen werden.');
    availableTickets = Array.isArray(data.tickets) ? data.tickets : [];
    showEvent(data.event || {});
    renderTickets(availableTickets);
  } catch (error) {
    ticketList.textContent = error.message || 'Ticketinformationen konnten gerade nicht geladen werden.';
    ticketList.className = 'ticket-list muted';
    submitButton.disabled = true;
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const items = selectedItems();
  if (!items.length) {
    setStatus('Bitte wähle mindestens ein Ticket aus.', true);
    return;
  }
  const totalCount = items.reduce((sum, item) => sum + item.quantity, 0);
  if (totalCount > 10) {
    setStatus('Pro Reservierung sind maximal 10 Tickets möglich.', true);
    return;
  }
  const name = document.querySelector('#visitor-name').value.trim();
  const email = document.querySelector('#visitor-email').value.trim();
  submitButton.disabled = true;
  submitButton.textContent = 'Reservierung wird gespeichert …';
  setStatus('Einen Moment bitte. Es wird keine Zahlung ausgelöst.');
  try {
    let requestKey = sessionStorage.getItem('ticketRequestKey');
    if (!requestKey) {
      requestKey = crypto.randomUUID();
      sessionStorage.setItem('ticketRequestKey', requestKey);
    }
    const response = await fetch('/api/reservations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ requestKey, name, email, items })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Die Reservierung konnte nicht gespeichert werden.');
    try {
      sessionStorage.setItem('ticketReservation', JSON.stringify(result));
      try { sessionStorage.removeItem('ticketRequestKey'); } catch { /* Ticket receipt is already saved. */ }
      window.location.assign('/bestaetigung');
    } catch {
      try {
        renderInlineConfirmation(result);
      } catch {
        setStatus('Deine Reservierung wurde gespeichert, aber die Tickets konnten nicht angezeigt werden. Bitte wende dich mit deinem Namen und der angegebenen E-Mail-Adresse an die Veranstaltungsleitung. Es wird keine Bestätigungsmail versendet.', true);
        submitButton.textContent = 'Reservierung gespeichert';
      }
    }
  } catch (error) {
    setStatus(error.message || 'Die Reservierung konnte gerade nicht gespeichert werden.', true);
    submitButton.disabled = false;
    submitButton.textContent = 'Tickets reservieren';
  }
});

loadEvent();
