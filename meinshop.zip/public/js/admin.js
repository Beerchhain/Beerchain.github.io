let csrfToken = '';
const loginPanel = document.querySelector('#login-panel');
const adminPanel = document.querySelector('#admin-panel');
const loginStatus = document.querySelector('#login-status');
const adminStatus = document.querySelector('#admin-status');
const loginForm = document.querySelector('#admin-login-form');
const loginButton = document.querySelector('#login-button');
const eventForm = document.querySelector('#event-form');
const ticketEditor = document.querySelector('#ticket-editor');
const saveAllButton = document.querySelector('#save-all-button');
const reservationList = document.querySelector('#reservation-list');
const resetOpenButton = document.querySelector('#reset-reservations-open');
const resetDialog = document.querySelector('#reset-reservations-dialog');
const resetForm = document.querySelector('#reset-reservations-form');
const resetPhraseInput = document.querySelector('#reset-confirmation-input');
const resetSubmitButton = document.querySelector('#reset-confirmation-submit');
const resetCancelButton = document.querySelector('#reset-cancel-button');
const resetStatus = document.querySelector('#reset-dialog-status');
const RESET_CONFIRMATION_PHRASE = 'ALLE RESERVIERUNGEN LÖSCHEN';

function money(cents) {
  return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(Number(cents || 0) / 100);
}

function setMessage(element, message, isError = false) {
  element.textContent = message;
  element.classList.toggle('error', isError);
}

async function request(path, options = {}) {
  const headers = { Accept: 'application/json', 'X-Public-Origin': window.location.origin, ...(options.headers || {}) };
  if (options.body !== undefined) headers['Content-Type'] = 'application/json';
  if (options.method && !['GET', 'HEAD'].includes(options.method.toUpperCase()) && csrfToken) {
    headers['X-CSRF-Token'] = csrfToken;
  }
  const response = await fetch(path, {
    ...options,
    headers,
    credentials: 'same-origin',
    body: options.body === undefined ? undefined : JSON.stringify(options.body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || 'Die Anfrage konnte nicht verarbeitet werden.');
    error.status = response.status;
    throw error;
  }
  return data;
}

function showLogin(message = '') {
  loginPanel.classList.remove('hidden');
  adminPanel.classList.add('hidden');
  if (message) setMessage(loginStatus, message, true);
}

function showAdmin() {
  loginPanel.classList.add('hidden');
  adminPanel.classList.remove('hidden');
}

function queryErrorMessage() {
  const code = new URLSearchParams(window.location.search).get('error');
  const messages = {
    state: 'Die Anmeldung ist abgelaufen oder konnte nicht bestätigt werden. Bitte versuche es erneut.',
    setup: 'Die Admin-Anmeldung ist noch nicht vollständig eingerichtet.',
    oauth: 'Die Manus-Anmeldung ist fehlgeschlagen. Bitte versuche es erneut.',
    'not-admin': 'Dieses Manus-Konto ist nicht für die Ticketverwaltung freigeschaltet.'
  };
  return messages[code] || '';
}

function makeField(labelText, value, type = 'text', options = {}) {
  const wrapper = document.createElement('div');
  const label = document.createElement('label');
  const id = `ticket-${Math.random().toString(36).slice(2, 10)}`;
  label.htmlFor = id;
  label.textContent = labelText;
  const field = options.multiline ? document.createElement('textarea') : document.createElement('input');
  field.id = id;
  field.name = options.name;
  field.value = value ?? '';
  field.maxLength = options.maxLength || 3000;
  if (!options.multiline) field.type = type;
  wrapper.append(label, field);
  return { wrapper, field };
}

function renderEvent(event) {
  eventForm.elements.eventTitle.value = event.eventTitle || '';
  eventForm.elements.eventDate.value = event.eventDate || '';
  eventForm.elements.schoolName.value = event.schoolName || '';
  eventForm.elements.eventLocation.value = event.eventLocation || '';
  eventForm.elements.visitorInstructions.value = event.visitorInstructions || '';
}

function renderTicketEditor(tickets) {
  ticketEditor.replaceChildren();
  tickets.forEach((ticket) => {
    const card = document.createElement('div');
    card.className = 'ticket-edit-card';
    card.dataset.ticketId = ticket.id;
    const title = document.createElement('h3');
    title.textContent = ticket.name;
    const nameField = makeField('Anzeigename', ticket.name, 'text', { name: 'name', maxLength: 120 });
    const descriptionField = makeField('Beschreibung', ticket.description, 'text', { name: 'description', maxLength: 3000, multiline: true });
    const priceField = makeField('Preis in Euro', (ticket.priceCents / 100).toFixed(2), 'number', { name: 'price', maxLength: 15 });
    priceField.field.step = '0.01';
    priceField.field.required = true;
    priceField.field.min = '0';
    priceField.field.max = '10000';
    priceField.field.classList.add('ticket-price-edit');
    const activeLabel = document.createElement('label');
    activeLabel.className = 'checkbox-line';
    const activeField = document.createElement('input');
    activeField.type = 'checkbox';
    activeField.name = 'isActive';
    activeField.checked = ticket.isActive;
    activeLabel.append(activeField, document.createTextNode('Ticket zur Reservierung anbieten'));
    card.append(title, nameField.wrapper, descriptionField.wrapper, priceField.wrapper, activeLabel);
    ticketEditor.append(card);
  });
}

function reservationCard(reservation) {
  const card = document.createElement('article');
  card.className = 'reservation-admin-card';
  const head = document.createElement('div');
  head.className = 'reservation-admin-head';
  const customer = document.createElement('div');
  const name = document.createElement('h3');
  name.textContent = reservation.fullName;
  const email = document.createElement('p');
  email.textContent = reservation.email;
  customer.append(name, email);
  const deliveryStatus = document.createElement('span');
  const deliveryLabels = {
    not_sent: 'Screenshot statt E-Mail',
    sent: 'Historisch: E-Mail versendet',
    failed: 'Historisch: E-Mail abgelehnt',
    pending: 'Historisch: Mailstatus offen'
  };
  deliveryStatus.className = `reservation-delivery-status ${reservation.emailStatus || 'unknown'}`;
  deliveryStatus.textContent = deliveryLabels[reservation.emailStatus] || 'Status unbekannt';
  head.append(customer, deliveryStatus);

  const ticketWrap = document.createElement('div');
  ticketWrap.className = 'reservation-ticket-list';
  reservation.tickets.forEach((ticket) => {
    const code = document.createElement('span');
    code.className = 'reservation-ticket-code';
    code.textContent = `${ticket.ticketName}: ${ticket.ticketCode}`;
    ticketWrap.append(code);
  });
  const actionRow = document.createElement('div');
  actionRow.className = 'reservation-admin-actions';
  const meta = document.createElement('p');
  meta.className = 'reservation-admin-meta';
  const created = new Date(reservation.createdAt);
  const formatted = Number.isNaN(created.getTime()) ? '' : created.toLocaleString('de-DE');
  meta.textContent = `${formatted} · ${reservation.tickets.length} ${reservation.tickets.length === 1 ? 'Ticket' : 'Tickets'} · ${money(reservation.totalCents)} · keine Onlinezahlung`;
  actionRow.append(meta);
  card.append(head, ticketWrap, actionRow);
  return card;
}

function renderReservations(reservations, { append = false, hasMore = false, nextCursor = '' } = {}) {
  const existingLoadMore = reservationList.querySelector('[data-load-more]');
  if (existingLoadMore) existingLoadMore.remove();
  if (!append) reservationList.replaceChildren();
  if (!reservations.length && !append) {
    const empty = document.createElement('p');
    empty.className = 'muted';
    empty.textContent = 'Es sind noch keine Reservierungen eingegangen.';
    reservationList.append(empty);
    return;
  }
  reservations.forEach((reservation) => reservationList.append(reservationCard(reservation)));
  if (hasMore) {
    const button = document.createElement('button');
    button.className = 'button button-outline';
    button.type = 'button';
    button.dataset.loadMore = 'true';
    button.textContent = 'Ältere Bestellungen laden';
    button.addEventListener('click', async () => {
      button.disabled = true;
      try { await loadDashboard(nextCursor, true); }
      catch (error) { setMessage(adminStatus, error.message, true); button.disabled = false; }
    });
    reservationList.append(button);
  }
}

async function loadDashboard(cursor = '', append = false) {
  const query = cursor ? `?cursor=${encodeURIComponent(cursor)}` : '';
  const data = await request(`/api/admin/dashboard${query}`);
  if (!append) {
    renderEvent(data.event);
    renderTicketEditor(data.tickets || []);
  }
  renderReservations(data.reservations || [], { append, hasMore: data.hasMore, nextCursor: data.nextCursor });
}

async function saveAllChanges() {
  if (saveAllButton.disabled || !eventForm.reportValidity()) return;
  const event = {
    eventTitle: eventForm.elements.eventTitle.value.trim(),
    eventDate: eventForm.elements.eventDate.value.trim(),
    schoolName: eventForm.elements.schoolName.value.trim(),
    eventLocation: eventForm.elements.eventLocation.value.trim(),
    visitorInstructions: eventForm.elements.visitorInstructions.value.trim()
  };
  if (event.eventTitle.length < 2) {
    setMessage(adminStatus, 'Der Veranstaltungstitel muss mindestens zwei Zeichen haben.', true);
    return;
  }

  const cards = [...ticketEditor.querySelectorAll('.ticket-edit-card')];
  if (cards.length !== 2) {
    setMessage(adminStatus, 'Die beiden Ticketarten konnten nicht vollständig geladen werden.', true);
    return;
  }
  const tickets = [];
  for (const card of cards) {
    const nameInput = card.querySelector('[name="name"]');
    const descriptionInput = card.querySelector('[name="description"]');
    const priceInput = card.querySelector('[name="price"]');
    const activeInput = card.querySelector('[name="isActive"]');
    const price = Number(priceInput.value);
    const priceCents = Math.round(price * 100);
    if (nameInput.value.trim().length < 2 || !priceInput.checkValidity() || !Number.isSafeInteger(priceCents) || priceCents > 1000000) {
      setMessage(adminStatus, 'Bitte prüfe bei beiden Tickets den Namen und den Preis (0 bis 10.000 €).', true);
      if (!priceInput.checkValidity()) priceInput.reportValidity();
      else nameInput.focus();
      return;
    }
    tickets.push({
      id: card.dataset.ticketId,
      name: nameInput.value.trim(),
      description: descriptionInput.value.trim(),
      priceCents,
      isActive: activeInput.checked
    });
  }

  const fields = [...eventForm.querySelectorAll('input, textarea'), ...ticketEditor.querySelectorAll('input, textarea')];
  const previousDisabled = fields.map((field) => field.disabled);
  fields.forEach((field) => { field.disabled = true; });
  saveAllButton.disabled = true;
  saveAllButton.textContent = 'Wird gespeichert …';
  setMessage(adminStatus, 'Speichere Veranstaltung und beide Ticketarten gemeinsam …');
  try {
    await request('/api/admin/save-all', { method: 'PUT', body: { event, tickets } });
    setMessage(adminStatus, 'Änderungen gespeichert. Die Website zeigt jetzt die neuen Veranstaltungs- und Ticketangaben.');
    try {
      await loadDashboard();
    } catch {
      setMessage(adminStatus, 'Änderungen sind gespeichert. Die aktuelle Ansicht konnte nicht neu geladen werden; lade die Verwaltung bitte neu.', true);
    }
  } catch (error) {
    setMessage(adminStatus, error.message || 'Änderungen konnten nicht gespeichert werden. Deine Eingaben sind erhalten geblieben.', true);
  } finally {
    fields.forEach((field, index) => { field.disabled = previousDisabled[index]; });
    saveAllButton.disabled = false;
    saveAllButton.textContent = 'Änderungen speichern';
  }
}

saveAllButton.addEventListener('click', saveAllChanges);

resetOpenButton.addEventListener('click', () => {
  resetForm.reset();
  resetSubmitButton.disabled = true;
  setMessage(resetStatus, '');
  resetDialog.showModal();
  resetPhraseInput.focus();
});

resetPhraseInput.addEventListener('input', () => {
  resetSubmitButton.disabled = resetPhraseInput.value !== RESET_CONFIRMATION_PHRASE || resetForm.dataset.busy === 'true';
});

resetCancelButton.addEventListener('click', () => resetDialog.close());
resetDialog.addEventListener('cancel', (event) => {
  if (resetForm.dataset.busy === 'true') event.preventDefault();
});
resetDialog.addEventListener('close', () => {
  if (resetForm.dataset.busy === 'true') return;
  resetForm.reset();
  resetPhraseInput.disabled = false;
  resetCancelButton.disabled = false;
  resetOpenButton.disabled = false;
  resetSubmitButton.disabled = true;
  resetSubmitButton.textContent = 'Endgültig löschen';
  setMessage(resetStatus, '');
});

resetForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (resetForm.dataset.busy === 'true') return;
  if (resetPhraseInput.value !== RESET_CONFIRMATION_PHRASE) {
    setMessage(resetStatus, 'Der Bestätigungstext muss exakt übereinstimmen.', true);
    resetPhraseInput.focus();
    return;
  }

  resetForm.dataset.busy = 'true';
  resetPhraseInput.disabled = true;
  resetCancelButton.disabled = true;
  resetOpenButton.disabled = true;
  resetSubmitButton.disabled = true;
  resetSubmitButton.textContent = 'Löschung läuft …';
  setMessage(resetStatus, 'Lösche alle Reservierungen und Ticketnummern endgültig …');
  try {
    const result = await request('/api/admin/reset-reservations', {
      method: 'POST',
      body: { confirmationPhrase: resetPhraseInput.value }
    });
    const deletedReservations = Number(result.deletedReservations || 0);
    const deletedTickets = Number(result.deletedTickets || 0);
    const summary = `Endgültig gelöscht: ${deletedReservations} ${deletedReservations === 1 ? 'Reservierung' : 'Reservierungen'} und ${deletedTickets} ${deletedTickets === 1 ? 'Ticketnummer' : 'Ticketnummern'}.`;
    resetForm.dataset.busy = 'false';
    resetDialog.close();
    try {
      await loadDashboard();
      setMessage(adminStatus, summary);
    } catch {
      setMessage(adminStatus, `${summary} Die Bestellliste konnte nicht neu geladen werden; lade die Verwaltung bitte neu.`, true);
    }
  } catch (error) {
    setMessage(resetStatus, error.message || 'Der Reset konnte nicht abgeschlossen werden.', true);
  } finally {
    resetForm.dataset.busy = 'false';
    resetPhraseInput.disabled = false;
    resetCancelButton.disabled = false;
    resetOpenButton.disabled = false;
    resetSubmitButton.disabled = resetPhraseInput.value !== RESET_CONFIRMATION_PHRASE;
    resetSubmitButton.textContent = 'Endgültig löschen';
  }
});

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const email = loginForm.elements.email.value.trim();
  const password = loginForm.elements.password.value;
  let loginAccepted = false;
  loginButton.disabled = true;
  setMessage(loginStatus, 'Anmeldung wird geprüft …');
  try {
    await request('/api/auth/login', {
      method: 'POST',
      body: { email, password, origin: window.location.origin }
    });
    loginAccepted = true;
    const user = await request('/api/admin/me');
    csrfToken = user.csrfToken;
    loginForm.reset();
    showAdmin();
    document.querySelector('#admin-greeting').textContent = `Angemeldet als ${user.name || user.email}`;
    try {
      await loadDashboard();
      setMessage(adminStatus, 'Angemeldet. Die Verwaltung ist bereit.');
    } catch (error) {
      setMessage(adminStatus, `Anmeldung erfolgreich, aber die Verwaltungsdaten konnten nicht geladen werden: ${error.message}`, true);
    }
  } catch (error) {
    if (loginAccepted && error.status === 401) {
      setMessage(loginStatus, 'Die Anmeldung war erfolgreich, aber dein Browser hat die Sitzung nicht übernommen. Öffne die Verwaltung in einem neuen Tab und melde dich dort erneut an.', true);
    } else if (error.status === 429) {
      setMessage(loginStatus, 'Zu viele Fehlversuche. Bitte warte 15 Minuten und versuche es erneut.', true);
    } else if (!loginAccepted && error.status === 401) {
      setMessage(loginStatus, 'E-Mail-Adresse oder Passwort stimmen nicht. Bitte prüfe deine Eingaben.', true);
    } else {
      setMessage(loginStatus, error.message || 'Die Anmeldung konnte gerade nicht abgeschlossen werden.', true);
    }
    loginButton.disabled = false;
  } finally {
    loginForm.elements.password.value = '';
  }
});

eventForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  saveAllChanges();
});

document.querySelector('#logout-button').addEventListener('click', async (event) => {
  const button = event.currentTarget;
  button.disabled = true;
  try {
    await request('/api/admin/logout', { method: 'POST' });
    window.location.reload();
  } catch (error) {
    setMessage(adminStatus, error.message, true);
    button.disabled = false;
  }
});

async function initialise() {
  const errorMessage = queryErrorMessage();
  if (errorMessage) setMessage(loginStatus, errorMessage, true);
  try {
    const user = await request('/api/admin/me');
    csrfToken = user.csrfToken;
    showAdmin();
    document.querySelector('#admin-greeting').textContent = `Angemeldet als ${user.name || user.email}`;
    await loadDashboard();
  } catch (error) {
    showLogin(error.status === 403 ? error.message : errorMessage);
  }
}

initialise();
